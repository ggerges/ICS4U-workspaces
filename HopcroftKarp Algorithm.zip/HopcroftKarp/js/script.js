

var canvas = document.getElementById('myCanvas');
var ctx = canvas.getContext('2d');






function animate(){
	requestAnimationFrame(animate);
}





